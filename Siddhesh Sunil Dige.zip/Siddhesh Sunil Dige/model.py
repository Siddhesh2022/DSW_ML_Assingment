
import pandas as pd
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report, accuracy_score
from sklearn.impute import SimpleImputer

class BinaryClassificationModel:
    def __init__(self, train_data_path, test_data_path):
        self.train_data_path = train_data_path
        self.test_data_path = test_data_path
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.model = None

    def load(self):
        """Load training and testing data from CSV files"""
        self.train_data = pd.read_csv(self.train_data_path)
        self.test_data = pd.read_csv(self.test_data_path)

    def preprocess(self):
        """Preprocess the data"""

        # Define features and target variable for training and testing data
        X_train = self.train_data.drop(columns=['loan_status'])
        y_train = self.train_data['loan_status']
        X_test = self.test_data.drop(columns=['loan_status'])
        y_test = self.test_data['loan_status']

        # Split into training and test sets (80% train, 20% test)
        self.X_train, self.X_test, self.y_train, self.y_test = X_train, X_test, y_train, y_test

        # Identify categorical and numerical columns
        numerical_cols = X_train.select_dtypes(include=['int64', 'float64']).columns
        categorical_cols = X_train.select_dtypes(include=['object']).columns

        # Build a preprocessing pipeline
        numerical_pipeline = Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='mean')),  # Handle missing values
            ('scaler', StandardScaler())  # Standardize numerical features
        ])
        
        categorical_pipeline = Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='most_frequent')),  # Handle missing values
            ('onehot', OneHotEncoder(handle_unknown='ignore'))  # One-hot encoding for categorical features
        ])

        # Combine pipelines into a column transformer
        preprocessor = ColumnTransformer(
            transformers=[
                ('num', numerical_pipeline, numerical_cols),
                ('cat', categorical_pipeline, categorical_cols)
            ])

        # Apply preprocessing to the training and test features
        self.X_train = preprocessor.fit_transform(self.X_train)
        self.X_test = preprocessor.transform(self.X_test)

    def train_rf(self):
        """Train the RandomForestClassifier model"""
        self.model = RandomForestClassifier(random_state=42, n_jobs=-1, verbose=1)
        self.model.fit(self.X_train, self.y_train)

    def train_lr(self):
        """Train the Logistic Regression model"""
        self.model = LogisticRegression(random_state=42, max_iter=1000)
        self.model.fit(self.X_train, self.y_train)

    def train_svm(self):
        """Train the Support Vector Machine model"""
        self.model = SVC(random_state=42)
        self.model.fit(self.X_train, self.y_train)

    def train_dt(self):
        """Train the Decision Tree model"""
        self.model = DecisionTreeClassifier(random_state=42)
        self.model.fit(self.X_train, self.y_train)

    def train_nn(self):
        """Train the Neural Network model"""
        self.model = MLPClassifier(random_state=42, max_iter=1000)
        self.model.fit(self.X_train, self.y_train)

    def test(self):
        """Test the model and generate evaluation summary"""
        y_pred = self.model.predict(self.X_test)
        accuracy = accuracy_score(self.y_test, y_pred)
        print(f"Accuracy: {accuracy * 100:.2f}%")
        print("\nClassification Report:")
        print(classification_report(self.y_test, y_pred))

    def predict(self, new_data):
        """Predict on new data"""
        preprocessor = ColumnTransformer(
            transformers=[
                ('num', StandardScaler(), new_data.select_dtypes(include=['int64', 'float64']).columns),
                ('cat', OneHotEncoder(handle_unknown='ignore'), new_data.select_dtypes(include=['object']).columns)
            ])
        
        new_data_processed = preprocessor.fit_transform(new_data)
        return self.model.predict(new_data_processed)